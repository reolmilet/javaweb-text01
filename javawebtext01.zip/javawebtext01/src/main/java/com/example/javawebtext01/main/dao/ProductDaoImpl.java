package com.example.javawebtext01.main.dao;

import com.example.javawebtext01.main.dao.ProductDao;
import com.example.javawebtext01.main.pojo.Userdata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDaoImpl implements ProductDao {

    private Connection conn = null; // 数据库连接对象
    private PreparedStatement pstmt = null; // 数据库操作对象


    // 通过构造方法取得数据库连接
    public ProductDaoImpl(Connection conn) {

        this.conn = conn;
    }





    @Override
    public boolean add(Userdata userdata) throws Exception {
        boolean flag = false; // 定义标识
        String sql = "insert into users(userId, userName, password, sex, email) values(?,?,?,?,?)";

        this.pstmt = this.conn.prepareStatement(sql);// 实例化PrepareStatement对象


        this.pstmt.setInt(1, userdata.getUserId());
        this.pstmt.setString(2,userdata.getUserName());
        this.pstmt.setString(3,userdata.getPassword());
        this.pstmt.setString(4,userdata.getSex());
        this.pstmt.setString(5,userdata.getEmail());
        //System.out.println("product.getStudent_id()---"+product.getStudent_id());

        if (this.pstmt.executeUpdate() > 0) { // 更新记录的行数大于0
            flag = true; // 修改标识
        }
        this.pstmt.close(); // 关闭PreparedStatement操作
        return flag;
    }
}
