package com.example.javawebtext01.main.dao;

import com.example.javawebtext01.main.pojo.Userdata;

public interface ProductDao {
    boolean add(Userdata userdata) throws Exception;
}
